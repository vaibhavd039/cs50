<!DOCTYPE html>

<html>

    <head>
        <title>dump</title>
    </head>

    <body>
        <pre><?php print_r($variable); ?></pre>
    </body>

</html>